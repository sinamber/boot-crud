# Vuepress1.x + ElementUI

yarn:
1. yarn install
2. yarn run dos:dev 

npm:
1. npm install
2. npm run docs:dev
