---
home: true
actionText: JSON →
actionLink: /foo/
features:
- title: Foo
  details: This is foo
- title: Bar
  details: This is bar
- title: Foobar
  details: This is foobar
footer: Matrix | Copyright © since@2021 matrix.hikememo.com
---

---

:::: tabs
 
::: tab 常用命令
__markdown content__
### Hell World
:::
 
 
::: tab Linux
``` shell script 
# 查看JAVA进程
ps -ef|grep java

# 查看动态日志
tail -f 100n  xxx.log | grep 'xxx'

# 在大文件里面查找关键字

# 压缩文件
tar -xvzf xxx-20200101.txt.tar.gz xxx.txt

# 文件解压
tar -cvzf xxx-20200101.txt.tar.gz xyz.txt

# 文件拷贝
scp root@10.10.101.11:/home/root/foobar.txt ~/demo/


# 删除git无用信息
find . -name "*.iml" | xargs rm -rf
find . -name "*.project" | xargs rm -rf
find . -name "*.settings" | xargs rm -rf
find . -name "*.classpath" | xargs rm -rf
find . -name "*.DS_Store" | xargs rm -rf
find . -name "target" | xargs rm -rf
```
:::

::: tab mysql
```shell script
# mysql dump 数据
mysqldump -u root -p -h 127.0.0.1 --databases foobar --hex-blob > ~/foobar-20200101.sql

# mysql dump 无数据
mysqldump --no-data -u root -p -h 127.0.0.1  --databases foobar --hex-blob > ~/foobar-20200101.sql
```
:::
 
::::
