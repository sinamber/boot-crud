<template>
    <div>
        <div>
            <h2>FOOOOOBAAAZ</h2>
            <h2>{{foo}}</h2>
            <h3>{{bar}}</h3>
            <h4>{{x}}</h4>
            <h5>{{y}}</h5>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'DemoPage',
        props: ['foo', 'bar'],
        data() {
            return {
                x: 'XXXXXXXXXX',
                y: 'YYYYYYYYY'
            }
        },
        methods: {
            handleToggleShow() {
            }
        }
    }
</script>



