<template>
    <div>
        <div>
            <h1>{{foo}}</h1>
            <h1>{{bar}}</h1>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'Foobar',
        data() {
            return {
                foo: 'foo',
                bar: 'baz'
            }
        },
        methods: {
        }
    }
</script>



