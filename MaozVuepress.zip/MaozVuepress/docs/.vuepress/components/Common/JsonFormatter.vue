<template>
    <div>
        <el-row :gutter="24">
            <el-col :span="12">
                <el-card class="box-card">
                    <div slot="header" class="clearfix">
                        <span>JSON</span>
                        <el-button style="float: right; padding: 3px 0" type="text" @click="clear()">Clear</el-button>
                    </div>
                    <div class="box-body" :body-style="{ padding: '0px' }">
                        <textarea  v-model="input" style="width:100%;min-height:65vh;border: 1px solid #eaeaea;border-radius: 2px;" v-on:input="fmt()" placeholder="请输入JSON"></textarea>
                    </div>
                </el-card>
            </el-col>
            <el-col :span="12">
                <el-card class="box-card">
                    <div slot="header" class="clearfix">
                        <span>PrettyJSON</span>
                    </div>
                    <div class="box-body" :body-style="{ padding: '0px', minHeight:'65vh' }">
                        <json-viewer
                                :value="output"
                                :expand-depth=5
                                copyable
                                boxed
                                sort></json-viewer>
                    </div>
                </el-card>
            </el-col>
        </el-row>
    </div>
</template>

<script>
    export default {
        name: 'JsonFormatter',
        methods: {
            isJSON(str){
                if (typeof str == 'string') {
                    try {
                        var obj=JSON.parse(str);
                        if(typeof obj == 'object' && obj ){
                            return true;
                        }else{
                            return false;
                        }

                    } catch(e) {
                        console.log('error：'+str+'!!!'+e);
                        return false;
                    }
                }
            },
            fmt() {
                try{
                    this.output = JSON.parse(this.input);
                }catch (e) {
                    try{
                        this.output = this.input;
                    }catch (e) {
                        this.$message('json解析失败'+e);
                    }
                }
            },
            clear(){
                this.input = '';
                this.output = '';
            }
        },
        data() {
            return {
                input:'{"foo":"FOO","bar":"BAR"}',
                output:''
            }
        },
        mounted() {
            this.fmt();
        }
    }
</script>


<style lang="less" scoped>
    .box-body {
        min-height: 65vh;
    }
</style>

