module.exports = {
    title: 'Matrix',
    base: '/matrix/',
    description: 'welcome to the matrix',
    dest: './dist',
    port: 8888,
    plugins: [
        'vuepress-plugin-element-tabs',
        '@vuepress/back-to-top'
    ],
    themeConfig: {
        search: false,
        nav: [
            {text: 'Home', link: '/'},
            {text: 'JSON', link: '/json'},
            {text: 'FOO', link: '/foo/'},
            {text: 'Bar', link: '/bar/'},
            {
                text: 'github',
                items: [
                    {text: 'focus-outside', link: 'https://github.com/TaoXuSheng/focus-outside'},
                    {text: 'stylus-converter', link: 'https://github.com/TaoXuSheng/stylus-converter'},
                ]
            }
        ],
        sidebar: {
            '/foo/': [
                {
                    title: 'FOO',
                    collapsable: true,
                    children: [
                        'demo001',
                        'demo002',
                        'demo003'
                    ]
                }
            ],
            '/bar/': [
                {
                    title: 'bar001',
                    collapsable: false,
                    children: []
                },
                {
                    title: 'bar002',
                    collapsable: false,
                    children: []
                }
            ]
        }
    }
}
