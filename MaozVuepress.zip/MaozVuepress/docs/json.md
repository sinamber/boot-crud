<Common-JsonFormatter>
</Common-JsonFormatter>

<script>
export default {
    methods: {
    fmt() {
        this.$message('这是一条消息提示');
    }
  }
}
</script>
