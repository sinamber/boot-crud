var entityMap = {
		  ';': '&#59;',
		  ':': '&#58;',
		  '&': '&amp;',
		  '<': '&lt;',
		  '>': '&gt;',
		  '"': '&quot;',
		  "'": '&#39;',
		  '/': '&#x2F;',
		  '`': '&#x60;',
		  '=': '&#x3D;'
		};
StrUtil = window.StrUtil || {
	isBlank:function(str){
		return str == null || str == '';
	},
	isNotBlank:function(){
		return str != null && str != '';
	},
	capitalize:function(string) {
	    return string.charAt(0).toUpperCase() + string.slice(1);
	},
	toInt:function(num){
		if(num == undefined || num == null || num == '' || num == 'NaN'){
			num = '0';
		}
		return parseInt(num);
	},
	cutString:function(str,len){
		var len  = len | 10;
		if(str != null && str != ''){
			if(str.length > len){
				str = str.substring(0,len) + '...';
			}
		}
		return str;
	},
	subStr:function(str, len){
	    if(!str) { return ''; }
	        len = len > 0 ? len*2 : 280;
	    var count = 0,	//计数：中文2字节，英文1字节
	        temp = '';  //临时字符串
	    for (var i = 0;i < str.length;i ++) {
	    	if (str.charCodeAt(i) > 255) {
	        	count += 2;
	        } else {
	        	count ++;
	        }
	        //如果增加计数后长度大于限定长度，就直接返回临时字符串
	        if(count > len) { return temp; }
	        //将当前内容加到临时字符串
	         temp += str.charAt(i);
	    }
	    return str;
	},
	//字符串长度-中文和全角符号为1，英文、数字和半角为0.5
	getLength:function(str, shortUrl) {
		if (true == shortUrl) {
			return Math.ceil(str.replace(/((news|telnet|nttp|file|http|ftp|https):\/\/){1}(([-A-Za-z0-9]+(\.[-A-Za-z0-9]+)*(\.[-A-Za-z]{2,5}))|([0-9]{1,3}(\.[0-9]{1,3}){3}))(:[0-9]*)?(\/[-A-Za-z0-9_\$\.\+\!\*\(\),;:@&=\?\/~\#\%]*)*/ig, 'http://goo.gl/fkKB ')
								.replace(/^\s+|\s+$/ig,'').replace(/[^\x00-\xff]/ig,'xx').length/2);
		} else {
			return Math.ceil(str.replace(/^\s+|\s+$/ig,'').replace(/[^\x00-\xff]/ig,'xx').length/2);
		}
	},
	getUUID:function() {
	    var d = new Date().getTime();
	    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
	        var r = (d + Math.random()*16)%16 | 0;
	        d = Math.floor(d/16);
	        return (c=='x' ? r : (r&0x7|0x8)).toString(16);
	    });
	    return uuid;
	},
	fixNull:function(str){
		return str || '';
	},
	escapeHtml:function(string){
		return String(string).replace(/[&<>"'`=\/]/g, function (s) {
		    return entityMap[s];
		  });
	},
	isMobile:function(mobile){
		var flag = false;
		if(mobile!=null && mobile.length == 11 && /^((\(\d{3}\))|(\d{3}\-))?1[38][0-9]\d{8}?$|15[0-35-9]\d{8}?$/.test(mobile)){
			flag = true;
		}
		return flag;
	},
	isEmail:function(email){
		var flag = false;
		if(email!=null && /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(email)){
			flag = true;
		}
		return flag;
	},
	trim:function(str){
		if(str == null){
			return str;
		}
		return str.replace(/(^\s*)|(\s*$)/g, '');
	}
}

var aceEditor;

var MatrixEditor = {
	initAceEditor:function(){
		$('#raw-json').height( $('#card-body').height() );
		aceEditor = ace.edit('raw-json');
		aceEditor.setShowPrintMargin(false);
		aceEditor.setTheme("ace/theme/twilight");
		aceEditor.getSession().setMode("ace/mode/json");
		aceEditor.getSession().setTabSize(2);
		aceEditor.getSession().setUseWrapMode(true);
	},
	bindPasteEevent:function(){
		aceEditor.on("paste", function(e){
			var data = e.text;
			try{
				var json = JSON.parse(data);
				var output = js_beautify(data);
				e.text = output;
				
				MatrixEditor.initJSONTree(output);
			}catch(e){
				//ignored
			}
		});
	},
	initJSONTree:function(data){
		var treeJSON = $('#tree-json');
		treeJSON.html(data);
		treeJSON.jsonFormatter();
	},
	formatJSON:function(){
		$('#format-btn').on('click',function(){
			try{
				var output = js_beautify(aceEditor.getValue());
				aceEditor.setValue(output);
				MatrixEditor.initJSONTree(output);
			}catch (e) {
				//ignord
			}
		});
	},
	getIds:function(){
		$('#getids-html-btn').on('click',function(){
			var output = StrUtil.escapeHtml(aceEditor.getValue());
			
			var ids = output.split('\n');
			
			var idsStr = "";
			for(var i=0;i<ids.length;i++){
				idsStr = idsStr + "'"+ids[i]+"',";
			}
			//aceEditor.setValue(idsStr);
			MatrixEditor.setResult(idsStr);
		});
	},
	md5:function(){
		$('#md5-btn').on('click',function(){
			var output = StrUtil.escapeHtml(aceEditor.getValue());
			var ids = output.split('\n');
			var idsStr = "";
			for(var i=0;i<ids.length;i++){
				idsStr = idsStr + md5(ids[i]) +"\n";
			}
			//aceEditor.setValue(idsStr);
			MatrixEditor.setResult(idsStr);
		});
	},
	base64encode:function(){
		$('#base64encoed-btn').on('click',function(){
			var input = aceEditor.getValue();
			var output = Base64.encode(input);
			MatrixEditor.setResult(output);
		});
	},
	base64decode:function(){
		$('#base64decode-btn').on('click',function(){
			var input = aceEditor.getValue();
			var output = Base64.decode(input);
			MatrixEditor.setResult(output);
		});
	},
	decode:function(){
		$('#decode-btn').on('click',function(){
			var output = StrUtil.escapeHtml(aceEditor.getValue());
			var datas = output.split('\n');
			$.ajax({
				traditional: true,
				url:'/decodeData',
				method:'POST',
				data:{
					datas:datas,
				},
				success:function(resp){
					var output = "";
					
					for(var i=0;i<resp.length;i++){
						output = output + resp[i] +"\n";
					}
					
					aceEditor.setValue(output);
				}
			})
			
		});
	},
	copy:function(){
		$('#copy-btn').on('click',function(){
			new ClipboardJS('#copy-btn', {
			    text: function(trigger) {
			    	swal("Copy Success!", "the content is in your clipboard!", "success",{
			    		 timer: 1700,
			    		 buttons: false
			    	});
			        return aceEditor.getValue();
			    }
			});
		});
	},
	clear:function(){
		$('#clear-btn').on('click',function(){
			aceEditor.setValue('');
			$('#jsonlintResult').html('');
			$('#jsonBeanCon').html('');
			$('#tree-json').html('');
		});
	},
	genCode:function(){
		$('#gen-btn').on('click',function(){
			chechJavaWords() && gen();
		});
	},
	setResult:function(result){
		var treeJSON = $('#tree-json');
		treeJSON.html(result);
	}
}


$(function(){
	MatrixEditor.initAceEditor();
	MatrixEditor.bindPasteEevent();
	MatrixEditor.formatJSON();
	MatrixEditor.getIds();
	MatrixEditor.md5();
	MatrixEditor.decode();
	MatrixEditor.copy();
	MatrixEditor.genCode();
	MatrixEditor.clear();
	MatrixEditor.base64encode();
	MatrixEditor.base64decode();
});