var javawordsStr = "abstract,assert,boolean,break,byte,case,catch,char,class,const,continue,default,do,double,else,enum,extends,final,finally,float,for,goto,if,implements,import,instanceof,int,interface,long,native,new,package,private,protected,public,return,strictfp,short,static,super,switch,synchronized,this,throw,throws,transient,try,void,volatile,while";

String.prototype.replaceAll = function(s1, s2) {
    return this.replace(new RegExp(s1, "gm"), s2);
}

function chechJavaWords() {
	var e = e = aceEditor.getValue().split("\n").join("").replace(/\s/g, "");
	e = e.split("\n").join(" ");
	for (var t = javawordsStr.split(","), n = 0; n < t.length; n++) {
		var i = t[n],
		o = '"' + i + '":',
		r = "'" + i + "':";
		if ( - 1 != e.indexOf(o) || -1 != e.indexOf(r)) return alertError({
			con: "要转换的JSON字符中出现了Java关键字:" + i
		}),
		!1
	}
	return ! 0
}


function gen() {
	try {
		var e = jsonlint.parse(aceEditor.getValue());
		var t = "RootBean";
		n = "com.code.monkey",
		i = aceEditor.getValue(),
		o = "json";
		
		
		if (i) {
			var r;
			if ("json" === o) r = getBeanFieldFromJson(i, t);
			else if ("sql" === o) return alert("还没实现"),void 0;
			
			
			
			$("#jsonBeanCon").html('');
			
			$.each(r,
			function(e, t) {
				var i = toBeanText(t, n);
				o = "";
				0 != e && (o = "small-text"),
				i = i.replaceAll("private int", "private Integer");
				i = i.replaceAll("private long", "private Long");
				i = i.replaceAll("private boolean", "private Boolean");
				i = i.replaceAll("private double", "private Double");
				i = i.replaceAll("private short", "private Short");
				
				//var r = '<div class="t-big-margin">\n        <h4 class="text-green">类名：' + t.name + "</h4>\n" + '<textarea class_name="' + t.name + '" row="10" class="form-control result ' + o + '" onmouseover="this.focus();this.select()">' + i + "</textarea></div>";
				
				var beanInfo = [];
				beanInfo.push('<div>')
				beanInfo.push('<div>'+t.name+' <button class="btn btn-success btn-sm" style="float:right;margin-right:12px;" id="copy-'+t.name+'" onclick="copyJava(\''+t.name+'\')">Copy</button> </div>')
				beanInfo.push('<div id="'+t.name+'" style="min-height:350px;margin-top:12px;"></div>')
				beanInfo.push('</div>')
				var r =  beanInfo.join('');
				
				$("#jsonBeanCon").append(r);
				
				
				var beanEditor = ace.edit(t.name);
				beanEditor.setShowPrintMargin(false);
				//beanEditor.setTheme("ace/theme/twilight");
				//beanEditor.setTheme("ace/theme/solarized_dark");
				//beanEditor.setTheme("ace/theme/kr_theme");
				//beanEditor.setTheme("ace/theme/tomorrow_night");
				//beanEditor.setTheme("ace/theme/gob");
				beanEditor.setTheme("ace/theme/monokai");
				//beanEditor.setTheme("ace/theme/eclipse");
				beanEditor.getSession().setMode("ace/mode/java");
				beanEditor.getSession().setTabSize(2);
				beanEditor.getSession().setUseWrapMode(true);
				beanEditor.setReadOnly(true);
				beanEditor.setValue( i );
				beanEditor.resize()
			}),
			$("#downloadJavaBean").show(),
			
			//$("#jsonlintResult").html("成功生成JavaBean");
			
			//swal("Gen JavaCode Success","let's take a look!", "success",{
	    	//	 timer: 1200,
	    	//	 buttons: false
	    	//});
			
			$.scrollTo( $('#jsonBeanCon') ,800,{ offset:{ top:0 } }); 
		}
	} catch(a) {
		document.getElementById("jsonlintResult").innerHTML = a,
		$("#jsonlintBox").addClass("alert-danger alert").removeClass("alert-warning alert-success"),
		$("#jsonlintIcon").addClass("icon-remove-sign").removeClass("icon-info-sign icon-ok-sign"),
		$("#download_btn").hide()
	}
}


function copyJava(id){
	var editor = ace.edit(id);
	var text = editor.getValue();
	
	new ClipboardJS('#copy-'+id, {
	    text: function(trigger) {
	    	swal("Copy Success","the content is in your clipboard!", "success",{
	    		 timer: 1200,
	    		 buttons: false
	    	});
	        return text;
	    }
	});
}


function trimStr(str) {
	return str.replace(/(^\s*)|(\s*$)/g, "");
}
function isArray(o) {
	return Object.prototype.toString.call(o) === '[object Array]';
}
function firstToUpperCase(str) {
	return str.substr(0, 1).toUpperCase() + str.substr(1);
}
function camelCase(input) {
	var input = input.replace(/\_(\w)/g,
			function(e, t) {
				return t.toUpperCase()
	});
	return input;
}
function camelCaseWithFirstCharUpper(input) {
	if (!input) {
		return ""
	};
	input = camelCase(input);
	return input[0].toUpperCase() + input.substr(1);
}
function isShortTime(str) {
	var a = str.match(/^(\d{1,2})(:)?(\d{1,2})\2(\d{1,2})$/);
	return a != null;
}
function strDateTime(str) {
	var r = str.match(/^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})$/);
	return r != null;
}
function strDateTime(str) {
	var reg = /^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2}) (\d{1,2}):(\d{1,2}):(\d{1,2})$/;
	var r = str.match(reg);
	return r != null;
}
function isDate(date) {
	var isDate = ((new Date(date) !== "Invalid Date" && !isNaN(new Date(date))) && isNaN(( + date)));
	return isDate;
}
function isInt(n) {
	return n % 1 === 0;
}
function currentYear() {
	return new Date().getFullYear()
}
function currentTime() {
	var date = new Date();
	var seperator1 = "-";
	var seperator2 = ":";
	var month = date.getMonth() + 1;
	var strDate = date.getDate();
	if (month >= 1 && month <= 9) {
		month = "0" + month;
	}
	if (strDate >= 0 && strDate <= 9) {
		strDate = "0" + strDate;
	}
	var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate + " " + date.getHours() + seperator2 + date.getMinutes() + seperator2 + date.getSeconds();
	return currentdate;
}
var importMap = {
	'Date': 'java.util.Date',
	'List': 'java.util.List'
}
function toBeanText(bean, packageName) {
	var beanFields = bean.val;
	var className = bean.name;
	var importText = "";
	var fieldText = "";
	var setterText = "";
	var typeSet = {};
	var shoudImportJackson = false;
	
	/*
	var tpl = "    public void setA(T a) {\n \
        this.a = a;\n \
    }\n \
    public T getA() {\n \
        return a;\n \
    }\n\n";
    */
	var tpl = "";
	
	for (key in beanFields) {
		console.log( key );
		var camelKey = camelCase(key);
		console.log( camelKey );
		
		if (camelKey != key) {
			fieldText += '    @JsonProperty("' + key + '")\n';
			shoudImportJackson = true;
		}
		fieldText += "    private " + beanFields[key] + " " + camelKey + ";\n";
		var type = beanFields[key];
		if (type.indexOf("List<") > -1) {
			type = beanFields[key].replace('List<', "");
			type = type.replace('>', "");
			typeSet["List"] = 'true';
		}
		typeSet[type] = 'true';
		var tplMap = {
			a: camelKey,
			A: firstToUpperCase(camelKey),
			T: beanFields[key]
		};
		setterText += tpl.replace(/a|A|T/g,
		function(matched) {
			return tplMap[matched];
		});
	}
	for (t in typeSet) {
		if (importMap[t]) {
			importText += "import " + importMap[t] + ";\n";
		}
	}
	if (shoudImportJackson) {
		importText += "import org.codehaus.jackson.annotate.JsonIgnoreProperties;\nimport org.codehaus.jackson.annotate.JsonProperty;\n"
	}
	
	importText += "import lombok.*; \n"
	importText += "import com.hx.csf.utils.model.ToString \n"
		
	if (packageName) {
		importText = "package " + packageName + ";\n" + importText;
	}
	return importText +  "\n \n @Data \n @AllArgsConstructor \n @NoArgsConstructor \n @Builder \n public class " + className + " extends ToString {\n\n" + fieldText + setterText + "}";
}
function getBeanFieldFromJson(text, className, type, typeCase) {
	var jsonObject = null;
	text = trimStr(text);
	try {
		jsonlint.parse(text);
	} catch(e) {}
	if (text[0] === "[" && text[text.length - 1] === "]") {
		text = '{ "list": ' + text + '}';
		jsonObject = JSON.parse(text).list[0];
	} else {
		jsonObject = JSON.parse(text);
	}
	var bean = {};
	var attrClassAry = [];
	for (key in jsonObject) {
		var val = jsonObject[key];
		var newKey = key;
		switch (type) {
		case '1':
			newKey = lineToHump(key) ;
			break;
		case '2':
			newKey = humpToLine(key);
			if (typeCase) {
				if (typeCase === '2') {
					newKey = newKey.toUpperCase()
				} else if (typeCase === '1') {
					newKey = newKey.toLowerCase()
				}
			}
			break;
		default:
			break;
		}
		bean[newKey] = getTypeFromJsonVal(val, newKey, attrClassAry, type, typeCase);
	}
	if (!className) {
		className = "AtoolBean";
	} else {}
	bean = {
		name: className,
		val: bean
	};
	return $.merge([bean], attrClassAry);
}
function lineToHump(name) {
	var html = name.replace(/\_(\w)/g,
	function(all, letter) {
		return letter.toUpperCase();
	});
	return html
}
function humpToLine(name) {
	return name.replace(/([A-Z])/g, "_$1").toLowerCase();
}
function getTypeFromJsonVal(val, key, attrClassAry, type, typeCase) {
	if (val && val.replace) {
		val = trimStr(val);
	}
	var typeofStr = typeof(val);
	if (typeofStr === 'number') {
		if (isInt(val)) {
			return val < 65536 ? "int": "long";
		} else {
			return "double";
		}
	} else if (typeofStr === 'boolean') {
		return typeofStr;
	} else if (isDate(val)) {
		return "Date";
	} else if (!val) {
		return "String";
	} else if (typeofStr === 'string') {
		return "String";
	} else {
		if (isArray(val)) {
			var type = getTypeFromJsonVal(val[0], key, attrClassAry);
			if (type == "int") {
				type = "Integer";
			} else if (type == "long") {
				type = "Long";
			} else if (type == "float") {
				type = "Float";
			} else if (type == "double") {
				type = "Double";
			}
			return "List<" + type + ">";
		} else {
			var typeName = camelCaseWithFirstCharUpper(key);
			var bean = {};
			for (key in val) {
				var fieldValue = val[key];
				var newKey = key;
				switch (type) {
				case '1':
					newKey = lineToHump(key);
					break;
				case '2':
					newKey = humpToLine(key);
					if (typeCase) {
						if (typeCase === '2') {
							newKey = newKey.toUpperCase()
						} else if (typeCase === '1') {
							newKey = newKey.toLowerCase()
						}
					}
					break;
				default:
					break;
				}
				bean[newKey] = getTypeFromJsonVal(fieldValue, newKey, attrClassAry, type, typeCase);
			}
			attrClassAry.push({
				name: typeName,
				val: bean
			});
			return typeName;
		}
	}
}