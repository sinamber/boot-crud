Kit = window.Kit || {
	go:function(url,timeout){
		if(url != null && url != ''){
			timeout = timeout || 1800;
			setTimeout(function(){
				document.location.href = url;
			},timeout);
		}
	},
	back:function(){
		 window.history.back();
	},
	to:function(url){
		document.location.href = url;
	},
	reload:function(){
		setTimeout(function(){
			document.location.reload();
		},1800);
	},
	TBD:function(){
		Kit.msg.info('功能开发中，敬请期待');
	},
	confirm:function(msg,myCallBack){
		/*Swal.fire({
			  title: '系统提示',
			  html: msg,
			  showDenyButton: true,
			  showCancelButton: false,
			  confirmButtonText: `确认`,
			  denyButtonText: `取消`,
			}).then((result) => {
			  if (result.isConfirmed) {
				  myCallBack();
			  }
		})*/
		HOLA.$confirm(msg, '提示', {
	        confirmButtonText: '确认',
	        cancelButtonText: '取消',
	        type: 'warning'
	      }).then(() => {
	    	  myCallBack()
	      })
	},
	msg:{
		CONST:{
			MSG_SUCCESS:"Success",
			MSG_FAIL:"FAIL",
			MSG_INFO:"MESSAEG",
			MSG_WARNING:"WARNING",
			MSG_ERROR:"SERVER ERROR",
			MSG_BAD_REQUEST:"FAIL TO REQUEST"
		},
		success:function(msg,callback){
			HOLA.$message({
		          message: msg,
		          type: 'success'
		    });
		},
		fail:function(msg,callback){
			HOLA.$message({
		          message: msg,
		          type: 'error'
		    });
		},
		info:function(msg,callback){
			HOLA.$message({
		          message: msg,
		          type: 'info'
		    });
		},
		warning:function(msg,callback){
			HOLA.$message({
		          message: msg,
		          type: 'warning'
		    });
		},
		error:function(msg,callback){
			HOLA.$message({
		          message: msg,
		          type: 'error'
		    });
		},
	},
	alert:{
		CONST:{
			MSG_SUCCESS:"Success",
			MSG_FAIL:"FAIL",
			MSG_INFO:"MESSAEG",
			MSG_WARNING:"WARNING",
			MSG_ERROR:"SERVER ERROR",
			MSG_BAD_REQUEST:"FAIL TO REQUEST"
		},
		success:function(msg,callback){
			this._showMsg({
				level:'SUCCESS',
				msg:msg,
				callback:callback
			});
		},
		fail:function(msg,callback){
			this._showMsg({
				level:'FAIL',
				msg:msg,
				callback:callback
			});
		},
		info:function(msg,callback){
			this._showMsg({
				level:'INFO',
				msg:msg,
				callback:callback
			});
		},
		warning:function(msg,callback){
			this._showMsg({
				level:'WARNING',
				msg:msg,
				callback:callback
			});
		},
		error:function(msg,callback){
			this._showMsg({
				level:'ERROR',
				msg:msg,
				callback:callback
			});
		},
		_showMsg:function(options){
			var opts = {
					msg:null,
					level:'ERROR',
					callback:null
			}
			opts = $.extend(opts, options);
			//fixed if the first param is function
			if(opts.msg != null && $.isFunction(opts.msg) ){
				opts.callback = opts.msg;
				opts.msg = null;
			}
			
			var _self = this;
			var msgTxt = '';
			
			switch (opts.level) {
			case 'SUCCESS':
				$.notify({
			            icon: "fa fa-check",
			            message: opts.msg || _self.CONST.MSG_SUCCESS
		        		}, {
		            type: 'success',
		            timer: 8000,
		            placement: {
		                from: 'top',
		                align: 'right'
		            }
		        });
				break;
			case 'FAIL':
				$.notify({
		            icon: "fa fa-times",
		            message: opts.msg || _self.CONST.MSG_FAIL
	        		}, {
	            type: 'danger',
	            timer: 8000,
	            placement: {
	                from: 'top',
	                align: 'right'
	            }
	        });
				break;
			case 'INFO':
				$.notify({
		            icon: "fa fa-info-circle",
		            message: opts.msg || _self.CONST.MSG_INFO
	        		}, {
	            type: 'info',
	            timer: 8000,
	            placement: {
	                from: 'top',
	                align: 'right'
	            		}
	        		})
				break;
			case 'WARNING':
				$.notify({
		            icon: "fa fa-exclamation-circle",
		            message: opts.msg || _self.CONST.MSG_INFO
	        		}, {
	            type: 'warning',
	            timer: 8000,
	            placement: {
	                from: 'top',
	                align: 'right'
	            	}
	        		});
				break;
			default://FAIL
				$.notify({
		            icon: "fa fa-times",
		            message: opts.msg || _self.CONST.MSG_ERROR
	        		}, {
	            type: 'danger',
	            timer: 8000,
	            placement: {
	                from: 'top',
	                align: 'right'
	            		}
	        		});
				break;
			}
			if(opts.callback != null && $.isFunction(opts.callback)){
				opts.callback();
			}
		}
	},
	box:function(options){
		var defaults = {
			title:'page info',
			content:'',
			size: '',   //sm , lg
			backdrop:true,
			keyboard:true,
			overlay:true,
			show:true,
			footer:true,
			remote:false,  //如果是，则在remote这里填写URL
			url:false,
			method:'GET',
			traditional: true,
			param:{},    //当remote有值时，需要传递的参数
			btn:''
		};
		var opts = $.extend(defaults, options);
		var jBoxWidth = 650;
		var jBoxHeight = 450;
		
		//close pre box
		if($('.jBox-closeButton').length == 1){
			$('.jBox-closeButton').click();
		}
		
		if(opts.size != ''){
			var sizeClass = '';
			if(opts.size == 'xs' ){
				var jBoxWidth = 300;
				var jBoxHeight = 100;
			}
			if(opts.size == 'sm' ){
				var jBoxWidth = 500;
				var jBoxHeight = 350;
			}
			if(opts.size == 'mid' ){
				var jBoxWidth = 650;
				var jBoxHeight = 450;
			}
			if(opts.size == 'lg' ) {
				var jBoxWidth =  $(window).width() - 300;
				var jBoxHeight = 800;
			}
			if(opts.size == 'xlg' ) {
				var jBoxWidth =  $(window).width() - 50;
				var jBoxHeight = 'auto';
			}
			$('#myUIBoxWrapper').addClass( sizeClass );
		};
		
		var ajaxOptions = null;
		if(opts.remote != ''){
			ajaxOptions = {
				type:opts.method,
				dataType:"html",
				cache: false,
				url: opts.remote,
				data: opts.param,
			    reload: false,
			    setContent: true,
			    traditional: true,
			    spinner: true	
			}
			opts.remote = false;
		}

		new jBox('Modal', {
			trigger:'click',
		    width: jBoxWidth,
		    height: jBoxHeight,
		    minWidth: 500,
		    minHeight: 100,
		    maxHeight: $(window).width() - 200,
		    maxHeight: $(window).height() - 150,
		    //animation:{open: 'tada', close: 'flip'},
		    //animation:{open: 'zoomIn', close: 'tada'},
		    overlay:opts.overlay,
		    closeOnClick: false,
		    appendTo:$('body'),
			draggable:'title',
		    attach: $('#myModal'),
		    title: opts.title,
		    ajax:ajaxOptions,
		    content: opts.content || '',
		    closeButton:'box',
		    onCreated: function() {
		    	if(opts.footer){
		    		this.footer = jQuery('<div class="jBox-Confirm-footer" style="text-align:right;"/>');
					jQuery('<span>'+opts.btn+'&nbsp;</span>').appendTo(this.footer);
					jQuery('<span style="margin:0 12px;"><a href="javascript:void(0)" class="btn btn-sm btn-danger">&nbsp;Close&nbsp;</a></span>').click(function() {this.options.cancel && this.options.cancel(); this.close();}.bind(this)).appendTo(this.footer);
					this.footer.appendTo(this.container);
		    	}
			},
			onCloseComplete: function() {
				this.destroy();
			}
		}).open();
	},
	boxClose:function(){
		$('.jBox-closeButton').click();
	},
	loading:function(obj){
		 //var loading = '<div class="overlay"><i class="fa fa-refresh fa-spin"></i></div>';
		 //$(loading).appendTo( obj );
		if(obj == null){
			NProgress.start();
		}else{
			obj.ploading({
				action: 'show',
				spinnerClass:'p-loading-spinner piano-spinner'	//piano-spinner | bubbling-spinner
			});
		}
	},
	unloading:function(obj){
		//obj.find('.overlay').remove();
		if(obj == null){
			NProgress.done();
		}else{
			obj.ploading({action: 'hide'});
			obj.ploading({action: 'destroy'});
		}
	},
};


StrUtil = window.StrUtil || {
	isBlank:function(str){
		return str == null || str == '';
	},
	isNotBlank:function(str){
		return str != null && str != '';
	},
	capitalize:function(string) {
	    return string.charAt(0).toUpperCase() + string.slice(1);
	},
	toInt:function(num){
		if(num == undefined || num == null || num == '' || num == 'NaN'){
			num = '0';
		}
		return parseInt(num);
	},
	cutString:function(str,len){
		var len  = len | 10;
		if(str != null && str != ''){
			if(str.length > len){
				str = str.substring(0,len) + '...';
			}
		}
		return str;
	},
	subStr:function(str, len){
	    if(!str) { return ''; }
	        len = len > 0 ? len*2 : 280;
	    var count = 0,	//计数：中文2字节，英文1字节
	        temp = '';  //临时字符串
	    for (var i = 0;i < str.length;i ++) {
	    	if (str.charCodeAt(i) > 255) {
	        	count += 2;
	        } else {
	        	count ++;
	        }
	        //如果增加计数后长度大于限定长度，就直接返回临时字符串
	        if(count > len) { return temp; }
	        //将当前内容加到临时字符串
	         temp += str.charAt(i);
	    }
	    return str;
	},
	//字符串长度-中文和全角符号为1，英文、数字和半角为0.5
	getLength:function(str, shortUrl) {
		if (true == shortUrl) {
			return Math.ceil(str.replace(/((news|telnet|nttp|file|http|ftp|https):\/\/){1}(([-A-Za-z0-9]+(\.[-A-Za-z0-9]+)*(\.[-A-Za-z]{2,5}))|([0-9]{1,3}(\.[0-9]{1,3}){3}))(:[0-9]*)?(\/[-A-Za-z0-9_\$\.\+\!\*\(\),;:@&=\?\/~\#\%]*)*/ig, 'http://goo.gl/fkKB ')
								.replace(/^\s+|\s+$/ig,'').replace(/[^\x00-\xff]/ig,'xx').length/2);
		} else {
			return Math.ceil(str.replace(/^\s+|\s+$/ig,'').replace(/[^\x00-\xff]/ig,'xx').length/2);
		}
	},
	getUUID:function() {
	    var d = new Date().getTime();
	    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
	        var r = (d + Math.random()*16)%16 | 0;
	        d = Math.floor(d/16);
	        return (c=='x' ? r : (r&0x7|0x8)).toString(16);
	    });
	    return uuid;
	},
	fixNull:function(str){
		return str || '';
	},
	escapeHtml:function(string){
		return String(string).replace(/[&<>"'`=\/]/g, function (s) {
		    return entityMap[s];
		  });
	},
	toJSONString:function(obj){
		if(this.isJSON(obj)){
			return JSON.stringify(obj);
		}else{
			return obj;
		}
	},
	isJSON:function(obj){
		var isjson = typeof(obj) == "object" && Object.prototype.toString.call(obj).toLowerCase() == "[object object]" && !obj.length; 
		return isjson;
	},
	isMobile:function(mobile){
		var flag = false;
		if(mobile!=null && mobile.length == 11 && /^((\(\d{3}\))|(\d{3}\-))?1[38][0-9]\d{8}?$|15[0-35-9]\d{8}?$/.test(mobile)){
			flag = true;
		}
		return flag;
	},
	isEmail:function(email){
		var flag = false;
		if(email!=null && /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(email)){
			flag = true;
		}
		return flag;
	},
	trim:function(str){
		if(str == null){
			return str;
		}
		return str.replace(/(^\s*)|(\s*$)/g, '');
	},
	fmtXML:function(xml){
		var reg = /(>)(<)(\/*)/g;
        var wsexp = / *(.*) +\n/g;
        var contexp = /(<.+>)(.+\n)/g;
        xml = xml.replace(reg, '$1\n$2$3').replace(wsexp, '$1\n').replace(contexp, '$1\n$2');
        var pad = 0;
        var formatted = '';
        var lines = xml.split('\n');
        var indent = 0;
        var lastType = 'other';
        // 4 types of tags - single, closing, opening, other (text, doctype, comment) - 4*4 = 16 transitions 
        var transitions = {
            'single->single': 0,
            'single->closing': -1,
            'single->opening': 0,
            'single->other': 0,
            'closing->single': 0,
            'closing->closing': -1,
            'closing->opening': 0,
            'closing->other': 0,
            'opening->single': 1,
            'opening->closing': 0,
            'opening->opening': 1,
            'opening->other': 1,
            'other->single': 0,
            'other->closing': -1,
            'other->opening': 0,
            'other->other': 0
        };

        for (var i = 0; i < lines.length; i++) {
            var ln = lines[i];
            var single = Boolean(ln.match(/<.+\/>/)); // is this line a single tag? ex. <br />
            var closing = Boolean(ln.match(/<\/.+>/)); // is this a closing tag? ex. </a>
            var opening = Boolean(ln.match(/<[^!].*>/)); // is this even a tag (that's not <!something>)
            var type = single ? 'single' : closing ? 'closing' : opening ? 'opening' : 'other';
            var fromTo = lastType + '->' + type;
            lastType = type;
            var padding = '';

            indent += transitions[fromTo];
            for (var j = 0; j < indent; j++) {
                padding += '\t';
            }
            if (fromTo == 'opening->closing')
                formatted = formatted.substr(0, formatted.length - 1) + ln + '\n'; // substr removes line break (\n) from prev loop
            else
                formatted += padding + ln + '\n';
        }
        return formatted;
	}
}