MatrixBox = window.MatrixBox || {
	resizeEditor:function(t, e, n, i){
		var o;
		  $(t).each(function(t, r) {
		    $(r) && $(r).draggable({
		      container: e[t],
		      move: !1,
		      before: function() {
		        o = $(e[t]).innerHeight()
		      },
		      drag: function(t) {
		        $(e).each(function(e, r) {
		          $(r) && (i ? $(r + " " + i).height(t.offset.y + o > n ? t.offset.y + o: n) : $(r + ".ace-editor").height(t.offset.y + o > n ? t.offset.y + o: n))
		        })
		      },
		      finish: function(t) {}
		    })
		  })
	},
}

