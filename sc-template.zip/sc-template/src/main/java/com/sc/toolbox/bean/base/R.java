package com.sc.toolbox.bean.base;

import com.sc.toolbox.enums.ResponseCodeEnum;


public class R<T> extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3414487038661126108L;

	public int code;

	public String msg;

	public T data;

	/**s
	 * 只允许通过静态方法创建对象
	 */
	private R() {
	}

	public static <T> R<T> success() {
		return R.success(null);
	}

	public static <T> R<T> success(T data) {
		return R.success(ResponseCodeEnum.OK.getMsg(), data);
	}

	public static <T> R<T> success(String msg, T data) {
		R<T> resp = new R<T>();
		resp.code = ResponseCodeEnum.OK.getCode();
		resp.msg = msg;
		resp.data = data;
		return resp;
	}

	public static <T> R<T> fail() {
		R<T> resp = new R<T>();
		resp.code = ResponseCodeEnum.FAIL.getCode();
		resp.msg = ResponseCodeEnum.FAIL.getMsg();
		return resp;
	}

	public static <T> R<T> fail(String msg) {
		R<T> resp = new R<T>();
		resp.code = ResponseCodeEnum.FAIL.getCode();
		resp.msg = msg;
		return resp;
	}

	public static <T> R<T> fail(int code, String msg, T data) {
		R<T> resp = new R<T>();
		resp.code = code;
		resp.msg = msg;
		resp.data = data;
		return resp;
	}

	public static <T> R<T> fail(String msg, T data) {
		R<T> resp = new R<T>();
		resp.code = ResponseCodeEnum.FAIL.getCode();
		resp.msg = msg;
		resp.data = data;
		return resp;
	}

	public static <T> R<T> badRequest() {
		R<T> resp = new R<T>();
		resp.code = ResponseCodeEnum.BAD_REQUEST.getCode();
		resp.msg = ResponseCodeEnum.BAD_REQUEST.getMsg();
		return resp;
	}

	public static <T> R<T> badRequest(String msg) {
		R<T> resp = new R<T>();
		resp.code = ResponseCodeEnum.BAD_REQUEST.getCode();
		resp.msg = msg;
		return resp;
	}

	public static <T> R<T> badRequest(String msg, T data) {
		R<T> resp = new R<T>();
		resp.code = ResponseCodeEnum.BAD_REQUEST.getCode();
		resp.msg = ResponseCodeEnum.BAD_REQUEST.getMsg();
		resp.data = data;
		return resp;
	}

	public static <T> R<T> error() {
		R<T> resp = new R<T>();
		resp.code = ResponseCodeEnum.SERVER_ERROR.getCode();
		resp.msg = ResponseCodeEnum.SERVER_ERROR.getMsg();
		return resp;
	}

	public static <T> R<T> error(String msg) {
		return error(msg, null);
	}

	public static <T> R<T> error(String msg, T data) {
		R<T> resp = new R<T>();
		resp.code = ResponseCodeEnum.SERVER_ERROR.getCode();
		resp.msg = msg;
		resp.data = data;
		return resp;
	}
}
