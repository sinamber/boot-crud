package com.sc.toolbox.web;

import org.springframework.web.servlet.ModelAndView;

public class BaseController {
	public ModelAndView view(String view) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName(view);
		return mv;
	}
}
