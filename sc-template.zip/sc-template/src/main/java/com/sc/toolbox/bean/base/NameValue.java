package com.sc.toolbox.bean.base;


/**
 * 名值对(一般用于下拉选)
 * 预留一个拓展字段obj,按需使用
 */
public class NameValue extends BaseEntity {
	private String name;
	private Object value;
	private Object obj;

	public NameValue() {
	}

	public NameValue(String name, Object value) {
		super();
		this.name = name;
		this.value = value;
	}

	public NameValue(String name, Object value, Object obj) {
		super();
		this.name = name;
		this.value = value;
		this.obj = obj;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}
}
