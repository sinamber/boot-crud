package com.sc.toolbox.bean.base;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;

import java.io.Serializable;

public abstract class BaseEntity implements Serializable {

	@Override
	public String toString() {
		try {
			return this.getClass().getSimpleName() + " = " + JSON.toJSONString(this, SerializerFeature.WriteMapNullValue);
		} catch (Exception e) {
			return super.toString();
		}
	}

}
