package com.sc.toolbox.util;

import cn.hutool.core.util.StrUtil;

public class StrUtils extends StrUtil{


	public static String getBeanName(String tableName) {
		tableName = toCamelStyle(tableName);
        int strLen;
        if (tableName == null || (strLen = tableName.length()) == 0) {
            return tableName;
        }
        return new StringBuilder(strLen)
            .append(Character.toTitleCase(tableName.charAt(0)))
            .append(tableName.substring(1))
            .toString();
    }


	public static String toCamelStyle(String columnName) {
	    columnName = columnName.toLowerCase();
		StringBuffer sb = new StringBuffer();
		boolean match = false;
		for (int i = 0; i < columnName.length(); i++) {
			char ch = columnName.charAt(i);
			if (match && ch >= 97 && ch <= 122) {
				ch -= 32;
			}
			if (ch != '_') {
				match = false;
				sb.append(ch);
			} else {
				match = true;
			}
		}
		return sb.toString();
	}

}
